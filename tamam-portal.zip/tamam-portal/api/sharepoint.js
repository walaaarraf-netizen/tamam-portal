const https = require('https');
const querystring = require('querystring');

const CONFIG = {
  tenantId: '81c593c6-a9c4-4bee-bf8b-3c2d75e6675a',
  clientId: 'b0862ae0-fa71-4b2c-ae5e-5a3d0a31746a',
  clientSecret: '1Dx8Q~q3nBod8xHQ~ZZgjdIdVQfMnTlDzqtgvchD',
  siteUrl: 'https://ashalholding.sharepoint.com/sites/DFSales',
  usersListName: 'DF Users',
  clientsListName: 'Sales_Clients',
  resource: 'https://ashalholding.sharepoint.com'
};

function httpsRequest(options, body = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch(e) { resolve({ status: res.statusCode, body: data }); }
      });
    });
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

async function getToken() {
  const body = querystring.stringify({
    grant_type: 'client_credentials',
    client_id: CONFIG.clientId,
    client_secret: CONFIG.clientSecret,
    scope: `${CONFIG.resource}/.default`
  });
  const res = await httpsRequest({
    hostname: 'login.microsoftonline.com',
    path: `/${CONFIG.tenantId}/oauth2/v2.0/token`,
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(body)
    }
  }, body);
  return res.body.access_token;
}

async function getDigest(token) {
  const url = new URL(`${CONFIG.siteUrl}/_api/contextinfo`);
  const res = await httpsRequest({
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json;odata=verbose',
      'Content-Length': 0
    }
  }, '');
  return res.body?.d?.GetContextWebInformation?.FormDigestValue || '';
}

async function spGet(token, listName, filter = '') {
  let path = `${new URL(CONFIG.siteUrl).pathname}/_api/lists/getbytitle('${encodeURIComponent(listName)}')/items?$top=500`;
  if (filter) path += `&$filter=${encodeURIComponent(filter)}`;
  const res = await httpsRequest({
    hostname: new URL(CONFIG.siteUrl).hostname,
    path,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json;odata=verbose'
    }
  });
  return res.body?.d?.results || [];
}

async function spPost(token, listName, item) {
  const digest = await getDigest(token);
  const metaPath = `${new URL(CONFIG.siteUrl).pathname}/_api/lists/getbytitle('${encodeURIComponent(listName)}')`;
  const metaRes = await httpsRequest({
    hostname: new URL(CONFIG.siteUrl).hostname,
    path: metaPath,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json;odata=verbose' }
  });
  const listItemType = metaRes.body?.d?.ListItemEntityTypeFullName;
  const bodyStr = JSON.stringify({ __metadata: { type: listItemType }, ...item });
  const path = `${new URL(CONFIG.siteUrl).pathname}/_api/lists/getbytitle('${encodeURIComponent(listName)}')/items`;
  const res = await httpsRequest({
    hostname: new URL(CONFIG.siteUrl).hostname,
    path,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json;odata=verbose',
      'Content-Type': 'application/json;odata=verbose',
      'X-RequestDigest': digest,
      'Content-Length': Buffer.byteLength(bodyStr)
    }
  }, bodyStr);
  return res;
}

async function spPatch(token, listName, itemId, item) {
  const digest = await getDigest(token);
  const metaPath = `${new URL(CONFIG.siteUrl).pathname}/_api/lists/getbytitle('${encodeURIComponent(listName)}')`;
  const metaRes = await httpsRequest({
    hostname: new URL(CONFIG.siteUrl).hostname,
    path: metaPath,
    method: 'GET',
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json;odata=verbose' }
  });
  const listItemType = metaRes.body?.d?.ListItemEntityTypeFullName;
  const bodyStr = JSON.stringify({ __metadata: { type: listItemType }, ...item });
  const path = `${new URL(CONFIG.siteUrl).pathname}/_api/lists/getbytitle('${encodeURIComponent(listName)}')/items(${itemId})`;
  const res = await httpsRequest({
    hostname: new URL(CONFIG.siteUrl).hostname,
    path,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/json;odata=verbose',
      'Content-Type': 'application/json;odata=verbose',
      'X-RequestDigest': digest,
      'IF-MATCH': '*',
      'X-HTTP-Method': 'MERGE',
      'Content-Length': Buffer.byteLength(bodyStr)
    }
  }, bodyStr);
  return res.status >= 200 && res.status < 300;
}

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.status(200).end(); return; }

  try {
    const token = await getToken();
    const { action } = req.query;

    if (action === 'login') {
      const { username, password } = req.body || {};
      const users = await spGet(token, CONFIG.usersListName, `UserName eq '${username}' and Password eq '${password}'`);
      if (!users.length) { res.status(401).json({ error: 'Invalid credentials' }); return; }
      res.json({ user: users[0] });

    } else if (action === 'getClients') {
      const { role, username, team } = req.query;
      let filter = '';
      if (role === 'sales-a') filter = `UserName eq '${username}' and Team eq 'A'`;
      else if (role === 'sales-b') filter = `UserName eq '${username}' and Team eq 'B'`;
      else if (role === 'leader-a') filter = "Team eq 'A'";
      else if (role === 'leader-b') filter = "Team eq 'B'";
      const clients = await spGet(token, CONFIG.clientsListName, filter);
      res.json({ clients });

    } else if (action === 'addClient') {
      const item = req.body || {};
      const result = await spPost(token, CONFIG.clientsListName, item);
      res.json({ success: true, result: result.body });

    } else if (action === 'updateClient') {
      const { id } = req.query;
      const item = req.body || {};
      const ok = await spPatch(token, CONFIG.clientsListName, id, item);
      res.json({ success: ok });

    } else {
      res.status(400).json({ error: 'Unknown action' });
    }
  } catch(e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
};
